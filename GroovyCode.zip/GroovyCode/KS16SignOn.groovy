import com.hyperionaddict.egress.EssSignOn

class KS16SignOn extends EssSignOn {

    KS16SignOn() {
        this.eu = 'epm_admin'
        this.ep = 'Passw0rd'
        this.eas = 'http://localhost:19000/aps/JAPI'
        this.svr = 'localhost'
    }
}
