usr='epm_admin'
pw='Passw0rd'
svr='localhost'
